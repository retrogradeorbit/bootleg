console={};
console.log={};
